-- MySQL dump 10.16  Distrib 10.1.26-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.1.26-MariaDB-0+deb9u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` varchar(0) DEFAULT NULL,
  `name` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` varchar(0) DEFAULT NULL,
  `group_id` varchar(0) DEFAULT NULL,
  `permission_id` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` tinyint(4) DEFAULT NULL,
  `content_type_id` tinyint(4) DEFAULT NULL,
  `codename` varchar(19) DEFAULT NULL,
  `name` varchar(24) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,1,'add_class','Can add class'),(2,1,'change_class','Can change class'),(3,1,'delete_class','Can delete class'),(4,1,'view_class','Can view class'),(5,2,'add_department','Can add department'),(6,2,'change_department','Can change department'),(7,2,'delete_department','Can delete department'),(8,2,'view_department','Can view department'),(9,3,'add_student','Can add student'),(10,3,'change_student','Can change student'),(11,3,'delete_student','Can delete student'),(12,3,'view_student','Can view student'),(13,4,'add_staff','Can add staff'),(14,4,'change_staff','Can change staff'),(15,4,'delete_staff','Can delete staff'),(16,4,'view_staff','Can view staff'),(17,5,'add_attendance','Can add attendance'),(18,5,'change_attendance','Can change attendance'),(19,5,'delete_attendance','Can delete attendance'),(20,5,'view_attendance','Can view attendance'),(21,6,'add_subject','Can add subject'),(22,6,'change_subject','Can change subject'),(23,6,'delete_subject','Can delete subject'),(24,6,'view_subject','Can view subject'),(25,7,'add_notice','Can add notice'),(26,7,'change_notice','Can change notice'),(27,7,'delete_notice','Can delete notice'),(28,7,'view_notice','Can view notice'),(29,8,'add_exam','Can add exam'),(30,8,'change_exam','Can change exam'),(31,8,'delete_exam','Can delete exam'),(32,8,'view_exam','Can view exam'),(33,9,'add_book','Can add book'),(34,9,'change_book','Can change book'),(35,9,'delete_book','Can delete book'),(36,9,'view_book','Can view book'),(37,10,'add_borrowrecord','Can add borrow record'),(38,10,'change_borrowrecord','Can change borrow record'),(39,10,'delete_borrowrecord','Can delete borrow record'),(40,10,'view_borrowrecord','Can view borrow record'),(41,11,'add_logentry','Can add log entry'),(42,11,'change_logentry','Can change log entry'),(43,11,'delete_logentry','Can delete log entry'),(44,11,'view_logentry','Can view log entry'),(45,12,'add_permission','Can add permission'),(46,12,'change_permission','Can change permission'),(47,12,'delete_permission','Can delete permission'),(48,12,'view_permission','Can view permission'),(49,13,'add_group','Can add group'),(50,13,'change_group','Can change group'),(51,13,'delete_group','Can delete group'),(52,13,'view_group','Can view group'),(53,14,'add_user','Can add user'),(54,14,'change_user','Can change user'),(55,14,'delete_user','Can delete user'),(56,14,'view_user','Can view user'),(57,15,'add_contenttype','Can add content type'),(58,15,'change_contenttype','Can change content type'),(59,15,'delete_contenttype','Can delete content type'),(60,15,'view_contenttype','Can view content type'),(61,16,'add_session','Can add session'),(62,16,'change_session','Can change session'),(63,16,'delete_session','Can delete session'),(64,16,'view_session','Can view session');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` tinyint(4) DEFAULT NULL,
  `password` varchar(78) DEFAULT NULL,
  `last_login` varchar(10) DEFAULT NULL,
  `is_superuser` tinyint(4) DEFAULT NULL,
  `username` varchar(5) DEFAULT NULL,
  `first_name` varchar(0) DEFAULT NULL,
  `email` varchar(0) DEFAULT NULL,
  `is_staff` tinyint(4) DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT NULL,
  `date_joined` varchar(10) DEFAULT NULL,
  `last_name` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$150000$PNkxSilEkpXx$o7VWubtobVN7z277vPrsbAtBG4oFZd+YTM75Tzbg9Yk=','2019-09-15',1,'admin','','',1,1,'2019-09-14','');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` varchar(0) DEFAULT NULL,
  `user_id` varchar(0) DEFAULT NULL,
  `group_id` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` varchar(0) DEFAULT NULL,
  `user_id` varchar(0) DEFAULT NULL,
  `permission_id` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` tinyint(4) DEFAULT NULL,
  `action_time` varchar(10) DEFAULT NULL,
  `object_id` tinyint(4) DEFAULT NULL,
  `object_repr` varchar(27) DEFAULT NULL,
  `change_message` varchar(38) DEFAULT NULL,
  `content_type_id` tinyint(4) DEFAULT NULL,
  `user_id` tinyint(4) DEFAULT NULL,
  `action_flag` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2019-09-14',1,'comp','[{\"added\": {}}]',2,1,1),(2,'2019-09-14',2,'entc','[{\"added\": {}}]',2,1,1),(3,'2019-09-14',3,'it','[{\"added\": {}}]',2,1,1),(4,'2019-09-14',1,'Physics','[{\"added\": {}}]',6,1,1),(5,'2019-09-14',2,'Maths 1','[{\"added\": {}}]',6,1,1),(6,'2019-09-14',3,'Maths 2','[{\"added\": {}}]',6,1,1),(7,'2019-09-14',4,'Maths 3','[{\"added\": {}}]',6,1,1),(8,'2019-09-14',5,'Chemistry','[{\"added\": {}}]',6,1,1),(9,'2019-09-14',6,'Comp Fundamentals','[{\"added\": {}}]',6,1,1),(10,'2019-09-14',7,'AI&R','[{\"added\": {}}]',6,1,1),(11,'2019-09-14',8,'DSA','[{\"added\": {}}]',6,1,1),(12,'2019-09-14',9,'OOP','[{\"added\": {}}]',6,1,1),(13,'2019-09-14',10,'SDL','[{\"added\": {}}]',6,1,1),(14,'2019-09-14',11,'SSL','[{\"added\": {}}]',6,1,1),(15,'2019-09-14',12,'Microprocessor','[{\"added\": {}}]',6,1,1),(16,'2019-09-14',7,'AI&R','',6,1,3),(17,'2019-09-14',8,'DSA','',6,1,3),(18,'2019-09-14',9,'OOP','',6,1,3),(19,'2019-09-14',10,'SDL','',6,1,3),(20,'2019-09-14',11,'SSL','',6,1,3),(21,'2019-09-14',13,'Object Oriented Programming','[{\"added\": {}}]',6,1,1),(22,'2019-09-14',14,'Data Structures','[{\"added\": {}}]',6,1,1),(23,'2019-09-14',15,'Microprocessor','[{\"added\": {}}]',6,1,1),(24,'2019-09-14',16,'Advanced Microprocessor','[{\"added\": {}}]',6,1,1),(25,'2019-09-14',17,'Software Testing','[{\"added\": {}}]',6,1,1),(26,'2019-09-14',18,'Soft Skills','[{\"added\": {}}]',6,1,1),(27,'2019-09-14',19,'Web Technology','[{\"added\": {}}]',6,1,1),(28,'2019-09-14',20,'Data Mining & Warehousing','[{\"added\": {}}]',6,1,1),(29,'2019-09-14',21,'Artificial Intelligence','[{\"added\": {}}]',6,1,1),(30,'2019-09-14',22,'Cyber Security','[{\"added\": {}}]',6,1,1),(31,'2019-09-14',23,'Software Development','[{\"added\": {}}]',6,1,1),(32,'2019-09-14',24,'Theory of Computation','[{\"added\": {}}]',6,1,1),(33,'2019-09-14',25,'DBMS','[{\"added\": {}}]',6,1,1),(34,'2019-09-14',26,'Computer Networks','[{\"added\": {}}]',6,1,1),(35,'2019-09-14',27,'Software Modelling','[{\"added\": {}}]',6,1,1),(36,'2019-09-14',28,'ES & IOT','[{\"added\": {}}]',6,1,1),(37,'2019-09-14',29,'System Programming and OS','[{\"added\": {}}]',6,1,1),(38,'2019-09-14',6,'Computer Fundamentals','[{\"changed\": {\"fields\": [\"name\"]}}]',6,1,2),(39,'2019-09-14',1,'fe1','[{\"added\": {}}]',1,1,1),(40,'2019-09-14',2,'fe2','[{\"added\": {}}]',1,1,1),(41,'2019-09-14',3,'fe3','[{\"added\": {}}]',1,1,1),(42,'2019-09-14',4,'fe4','[{\"added\": {}}]',1,1,1),(43,'2019-09-14',5,'fe5','[{\"added\": {}}]',1,1,1),(44,'2019-09-14',6,'fe6','[{\"added\": {}}]',1,1,1),(45,'2019-09-14',7,'fe7','[{\"added\": {}}]',1,1,1),(46,'2019-09-14',8,'fe8','[{\"added\": {}}]',1,1,1),(47,'2019-09-14',12,'Microprocessor','',6,1,3),(48,'2019-09-14',9,'se1','[{\"added\": {}}]',1,1,1),(49,'2019-09-14',10,'se2','[{\"added\": {}}]',1,1,1),(50,'2019-09-14',11,'se3','[{\"added\": {}}]',1,1,1),(51,'2019-09-14',12,'se4','[{\"added\": {}}]',1,1,1),(52,'2019-09-14',13,'te1','[{\"added\": {}}]',1,1,1),(53,'2019-09-14',14,'te2','[{\"added\": {}}]',1,1,1),(54,'2019-09-14',15,'te3','[{\"added\": {}}]',1,1,1),(55,'2019-09-14',16,'te4','[{\"added\": {}}]',1,1,1),(56,'2019-09-14',30,'Data Analytics','[{\"added\": {}}]',6,1,1),(57,'2019-09-14',31,'High Performance Computing','[{\"added\": {}}]',6,1,1),(58,'2019-09-14',17,'be1','[{\"added\": {}}]',1,1,1),(59,'2019-09-14',18,'be2','[{\"added\": {}}]',1,1,1),(60,'2019-09-14',19,'be3','[{\"added\": {}}]',1,1,1),(61,'2019-09-14',20,'be4','[{\"added\": {}}]',1,1,1),(62,'2019-09-14',5,'GirishPotdar','[{\"changed\": {\"fields\": [\"classes\"]}}]',4,1,2),(63,'2019-09-14',4,'PravinPatil','[{\"changed\": {\"fields\": [\"classes\"]}}]',4,1,2),(64,'2019-09-14',3,'BhushanZope','[{\"changed\": {\"fields\": [\"classes\"]}}]',4,1,2),(65,'2019-09-14',2,'SwarupSuradkar','[{\"changed\": {\"fields\": [\"classes\"]}}]',4,1,2),(66,'2019-09-14',1,'RanjeetBidwe','[{\"changed\": {\"fields\": [\"classes\"]}}]',4,1,2),(67,'2019-09-15',7,'Prasad Hole','[{\"changed\": {\"fields\": [\"classes\"]}}]',4,1,2);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` tinyint(4) DEFAULT NULL,
  `app_label` varchar(12) DEFAULT NULL,
  `model` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (11,'admin','logentry'),(13,'auth','group'),(12,'auth','permission'),(14,'auth','user'),(15,'contenttypes','contenttype'),(16,'sessions','session'),(5,'student_app','attendance'),(9,'student_app','book'),(10,'student_app','borrowrecord'),(1,'student_app','class'),(2,'student_app','department'),(8,'student_app','exam'),(7,'student_app','notice'),(4,'student_app','staff'),(3,'student_app','student'),(6,'student_app','subject');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` tinyint(4) DEFAULT NULL,
  `app` varchar(12) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `applied` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2019-09-14'),(2,'auth','0001_initial','2019-09-14'),(3,'admin','0001_initial','2019-09-14'),(4,'admin','0002_logentry_remove_auto_add','2019-09-14'),(5,'admin','0003_logentry_add_action_flag_choices','2019-09-14'),(6,'contenttypes','0002_remove_content_type_name','2019-09-14'),(7,'auth','0002_alter_permission_name_max_length','2019-09-14'),(8,'auth','0003_alter_user_email_max_length','2019-09-14'),(9,'auth','0004_alter_user_username_opts','2019-09-14'),(10,'auth','0005_alter_user_last_login_null','2019-09-14'),(11,'auth','0006_require_contenttypes_0002','2019-09-14'),(12,'auth','0007_alter_validators_add_error_messages','2019-09-14'),(13,'auth','0008_alter_user_username_max_length','2019-09-14'),(14,'auth','0009_alter_user_last_name_max_length','2019-09-14'),(15,'auth','0010_alter_group_name_max_length','2019-09-14'),(16,'auth','0011_update_proxy_permissions','2019-09-14'),(17,'sessions','0001_initial','2019-09-14'),(18,'student_app','0001_initial','2019-09-14'),(19,'student_app','0002_auto_20190912_2031','2019-09-14'),(20,'student_app','0003_attendance','2019-09-14'),(21,'student_app','0004_subject','2019-09-14'),(22,'student_app','0005_auto_20190913_1327','2019-09-14'),(23,'student_app','0006_auto_20190913_1337','2019-09-14'),(24,'student_app','0007_notice','2019-09-14'),(25,'student_app','0008_auto_20190913_1543','2019-09-14'),(26,'student_app','0009_exam','2019-09-14'),(27,'student_app','0010_auto_20190914_0042','2019-09-14'),(28,'student_app','0011_auto_20190914_0045','2019-09-14'),(29,'student_app','0012_book_borrowrecord','2019-09-14'),(30,'student_app','0013_remove_book_copies','2019-09-14'),(31,'student_app','0014_student_profile_pic','2019-09-14'),(32,'student_app','0015_auto_20190914_2133','2019-09-14'),(33,'student_app','0016_remove_student_profile_pic','2019-09-15'),(34,'student_app','0017_student_mobile_no','2019-09-15');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(32) DEFAULT NULL,
  `session_data` varchar(252) DEFAULT NULL,
  `expire_date` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('fc00qzcfo7elhmhcdg74svymid3hyayc','MWQ3ZDgyMzkzNzI2Nzg4MTA4ZDk3NWY1ZDhkODhiMzJjOGJjNzVmYjp7fQ==','2019-09-29'),('go8fcfqt38rjd3q32oqcxl5iegkifz17','YmRjYzAxMWNmOGQyOWRlZWVjMjZlMWFmNDBmNTMwMDA2MTViZTQwYTp7InVzZXJfdHlwZSI6InN0YWZmIiwic3RhZmZfaWQiOiJTVEYxMDAwIiwiY2MiOnRydWV9','2019-09-29'),('m3frrk6pile7i2badtu4jaata6pr7h41','ZDY5YTg2NDVmYzg0M2M2YTViOTE2ZmVjYzY5NmExN2U1YTYyMzIyNTp7InVzZXJfdHlwZSI6InN0dWRlbnQiLCJzdHVkZW50X2lkIjoiQzJLMTAwMiJ9','2019-09-29'),('7i9gjmvzyomq9d4qvk97q3vw65f6rd7h','MWQ3ZDgyMzkzNzI2Nzg4MTA4ZDk3NWY1ZDhkODhiMzJjOGJjNzVmYjp7fQ==','2019-09-29'),('3jgsdnf53dbo079lw3zrgwiiw49f5xn6','NmZiZTYxMTYwOWE2YWJhOWZkNGE3MzZhYTkwMmUxNjU2YjRmNjNhNTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0ODBiYzJhMzkxOWU3ZDFiYjYzMTM1OTdhY2MzODdjZWVmNDgxNzFmIn0=','2019-09-29'),('3etuat93890dtin0fucue98wwygucgz7','MWQ3ZDgyMzkzNzI2Nzg4MTA4ZDk3NWY1ZDhkODhiMzJjOGJjNzVmYjp7fQ==','2019-09-29'),('xanyvjdvg0o0py3tsjhs1ipoomxb6d7c','YmRjYzAxMWNmOGQyOWRlZWVjMjZlMWFmNDBmNTMwMDA2MTViZTQwYTp7InVzZXJfdHlwZSI6InN0YWZmIiwic3RhZmZfaWQiOiJTVEYxMDAwIiwiY2MiOnRydWV9','2019-09-29'),('1gj4zzyftecof7kuvo7k8qw6eken4zcb','MWQ3ZDgyMzkzNzI2Nzg4MTA4ZDk3NWY1ZDhkODhiMzJjOGJjNzVmYjp7fQ==','2019-09-29'),('mtm3ctc63nldxgpizeollhhcz1wkryml','ZDY5YTg2NDVmYzg0M2M2YTViOTE2ZmVjYzY5NmExN2U1YTYyMzIyNTp7InVzZXJfdHlwZSI6InN0dWRlbnQiLCJzdHVkZW50X2lkIjoiQzJLMTAwMiJ9','2019-09-29'),('rznxh87igt4w2rm37c7d35pscz8o87oy','NWI5YWMxNzU2ZDg3ZmRhMzNkOWY3NDZhZDFlMDM1OWY3MWU4MTM3OTp7InVzZXJfdHlwZSI6InN0dWRlbnQiLCJzdHVkZW50X2lkIjoiQzJLMTAwMCJ9','2019-09-29'),('t4akwk2x9kvh4e6yf7p0fp49yov9ohm5','MWQ3ZDgyMzkzNzI2Nzg4MTA4ZDk3NWY1ZDhkODhiMzJjOGJjNzVmYjp7fQ==','2019-09-29');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sqlite_sequence`
--

DROP TABLE IF EXISTS `sqlite_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sqlite_sequence` (
  `name` varchar(28) DEFAULT NULL,
  `seq` smallint(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sqlite_sequence`
--

LOCK TABLES `sqlite_sequence` WRITE;
/*!40000 ALTER TABLE `sqlite_sequence` DISABLE KEYS */;
INSERT INTO `sqlite_sequence` VALUES ('django_migrations',34),('django_admin_log',67),('django_content_type',16),('auth_permission',64),('auth_user',1),('auth_group',0),('student_app_class',20),('student_app_staff_classes',15),('student_app_attendance',47),('student_app_notice_class_obj',37),('student_app_book',10),('student_app_department',3),('student_app_subject',31),('student_app_class_subjects',124),('student_app_staff',8),('student_app_borrowrecord',4),('student_app_notice',12),('student_app_exam',4),('student_app_student',14);
/*!40000 ALTER TABLE `sqlite_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_app_attendance`
--

DROP TABLE IF EXISTS `student_app_attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_app_attendance` (
  `id` tinyint(4) DEFAULT NULL,
  `unique_id` varchar(36) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `taken_time` varchar(10) DEFAULT NULL,
  `marked_by_id` tinyint(4) DEFAULT NULL,
  `student_id` tinyint(4) DEFAULT NULL,
  `subject_id` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_app_attendance`
--

LOCK TABLES `student_app_attendance` WRITE;
/*!40000 ALTER TABLE `student_app_attendance` DISABLE KEYS */;
INSERT INTO `student_app_attendance` VALUES (36,'d7b0e2b9-805c-4b9f-a606-ba7b18e26c1b',1,'2019-09-15',1,1,20),(37,'d7b0e2b9-805c-4b9f-a606-ba7b18e26c1b',1,'2019-09-15',1,2,20),(38,'d7b0e2b9-805c-4b9f-a606-ba7b18e26c1b',1,'2019-09-15',1,3,20),(39,'d7b0e2b9-805c-4b9f-a606-ba7b18e26c1b',1,'2019-09-15',1,4,20),(40,'45e76b00-2f4f-4533-9754-f1bb7fc10c78',1,'2019-09-15',1,1,21),(41,'45e76b00-2f4f-4533-9754-f1bb7fc10c78',1,'2019-09-15',1,2,21),(42,'45e76b00-2f4f-4533-9754-f1bb7fc10c78',1,'2019-09-15',1,3,21),(43,'45e76b00-2f4f-4533-9754-f1bb7fc10c78',1,'2019-09-15',1,4,21),(44,'2c500f25-6895-4494-9c3b-322e3e0b994f',0,'2019-09-15',1,1,22),(45,'2c500f25-6895-4494-9c3b-322e3e0b994f',1,'2019-09-15',1,2,22),(46,'2c500f25-6895-4494-9c3b-322e3e0b994f',1,'2019-09-15',1,3,22),(47,'2c500f25-6895-4494-9c3b-322e3e0b994f',1,'2019-09-15',1,4,22);
/*!40000 ALTER TABLE `student_app_attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_app_book`
--

DROP TABLE IF EXISTS `student_app_book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_app_book` (
  `id` tinyint(4) DEFAULT NULL,
  `name` varchar(57) DEFAULT NULL,
  `isbn` varchar(18) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_app_book`
--

LOCK TABLES `student_app_book` WRITE;
/*!40000 ALTER TABLE `student_app_book` DISABLE KEYS */;
INSERT INTO `student_app_book` VALUES (1,'Into the Water','978-0-7352-1120-9'),(2,'We Were Eight Years in Power: An American Tragedy','978-0-399-59056-6'),(3,'Unstoppable: My Life So Far','978-0-374-27979-0'),(4,'Fly Me','978-0-316-36213-9'),(5,'Chemistry','978-1-5247-3174-8'),(6,'Win Bigly: Persuasion in a World Where Facts Don\'t Matter','978-0-7352-1971-7 '),(7,'The Incest Diary','978-0-374-17555-9'),(8,'Before We Were Yours','978-0-425-28468-1'),(9,'Manhattan Beach','978-1-4767-1673-2'),(10,'What to Do About the Solomons','978-0-8021-2457-9');
/*!40000 ALTER TABLE `student_app_book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_app_borrowrecord`
--

DROP TABLE IF EXISTS `student_app_borrowrecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_app_borrowrecord` (
  `id` tinyint(4) DEFAULT NULL,
  `borrow_time` varchar(10) DEFAULT NULL,
  `book_id` tinyint(4) DEFAULT NULL,
  `student_id` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_app_borrowrecord`
--

LOCK TABLES `student_app_borrowrecord` WRITE;
/*!40000 ALTER TABLE `student_app_borrowrecord` DISABLE KEYS */;
INSERT INTO `student_app_borrowrecord` VALUES (2,'2019-09-15',7,3),(3,'2019-09-15',3,3),(4,'2019-09-15',3,1);
/*!40000 ALTER TABLE `student_app_borrowrecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_app_class`
--

DROP TABLE IF EXISTS `student_app_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_app_class` (
  `id` tinyint(4) DEFAULT NULL,
  `name` varchar(3) DEFAULT NULL,
  `department_id` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_app_class`
--

LOCK TABLES `student_app_class` WRITE;
/*!40000 ALTER TABLE `student_app_class` DISABLE KEYS */;
INSERT INTO `student_app_class` VALUES (1,'fe1',1),(2,'fe2',1),(3,'fe3',1),(4,'fe4',1),(5,'fe5',3),(6,'fe6',3),(7,'fe7',2),(8,'fe8',2),(9,'se1',1),(10,'se2',1),(11,'se3',1),(12,'se4',1),(13,'te1',1),(14,'te2',1),(15,'te3',1),(16,'te4',1),(17,'be1',1),(18,'be2',1),(19,'be3',1),(20,'be4',1);
/*!40000 ALTER TABLE `student_app_class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_app_class_subjects`
--

DROP TABLE IF EXISTS `student_app_class_subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_app_class_subjects` (
  `id` smallint(6) DEFAULT NULL,
  `class_id` tinyint(4) DEFAULT NULL,
  `subject_id` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_app_class_subjects`
--

LOCK TABLES `student_app_class_subjects` WRITE;
/*!40000 ALTER TABLE `student_app_class_subjects` DISABLE KEYS */;
INSERT INTO `student_app_class_subjects` VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5),(6,1,6),(7,2,1),(8,2,2),(9,2,3),(10,2,4),(11,2,5),(12,2,6),(13,3,1),(14,3,2),(15,3,3),(16,3,4),(17,3,5),(18,3,6),(19,4,1),(20,4,2),(21,4,3),(22,4,4),(23,4,5),(24,4,6),(25,5,1),(26,5,2),(27,5,3),(28,5,4),(29,5,5),(30,5,6),(31,6,1),(32,6,2),(33,6,3),(34,6,4),(35,6,5),(36,6,6),(37,7,1),(38,7,2),(39,7,3),(40,7,4),(41,7,5),(42,7,6),(43,8,1),(44,8,2),(45,8,3),(46,8,4),(47,8,5),(48,8,6),(49,9,13),(50,9,14),(51,9,15),(52,9,16),(53,9,17),(54,9,18),(55,10,13),(56,10,14),(57,10,15),(58,10,16),(59,10,17),(60,10,18),(61,11,13),(62,11,14),(63,11,15),(64,11,16),(65,11,17),(66,11,18),(67,12,13),(68,12,14),(69,12,15),(70,12,16),(71,12,17),(72,12,18),(73,13,19),(74,13,23),(75,13,24),(76,13,25),(77,13,26),(78,13,27),(79,13,28),(80,13,29),(81,14,19),(82,14,23),(83,14,24),(84,14,25),(85,14,26),(86,14,27),(87,14,28),(88,14,29),(89,15,19),(90,15,23),(91,15,24),(92,15,25),(93,15,26),(94,15,27),(95,15,28),(96,15,29),(97,16,19),(98,16,23),(99,16,24),(100,16,25),(101,16,26),(102,16,27),(103,16,28),(104,16,29),(105,17,20),(106,17,21),(107,17,22),(108,17,30),(109,17,31),(110,18,20),(111,18,21),(112,18,22),(113,18,30),(114,18,31),(115,19,20),(116,19,21),(117,19,22),(118,19,30),(119,19,31),(120,20,20),(121,20,21),(122,20,22),(123,20,30),(124,20,31);
/*!40000 ALTER TABLE `student_app_class_subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_app_department`
--

DROP TABLE IF EXISTS `student_app_department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_app_department` (
  `id` tinyint(4) DEFAULT NULL,
  `name` varchar(4) DEFAULT NULL,
  `hod` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_app_department`
--

LOCK TABLES `student_app_department` WRITE;
/*!40000 ALTER TABLE `student_app_department` DISABLE KEYS */;
INSERT INTO `student_app_department` VALUES (1,'comp','Rajesh Ingle'),(2,'entc','Pralhad Kulkarni'),(3,'it','Anant Bagade');
/*!40000 ALTER TABLE `student_app_department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_app_exam`
--

DROP TABLE IF EXISTS `student_app_exam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_app_exam` (
  `id` varchar(0) DEFAULT NULL,
  `name` varchar(0) DEFAULT NULL,
  `marks` varchar(0) DEFAULT NULL,
  `publish_date` varchar(0) DEFAULT NULL,
  `student_id` varchar(0) DEFAULT NULL,
  `subject_id` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_app_exam`
--

LOCK TABLES `student_app_exam` WRITE;
/*!40000 ALTER TABLE `student_app_exam` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_app_exam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_app_notice`
--

DROP TABLE IF EXISTS `student_app_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_app_notice` (
  `id` tinyint(4) DEFAULT NULL,
  `title` varchar(11) DEFAULT NULL,
  `notice` varchar(176) DEFAULT NULL,
  `added_by_id` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_app_notice`
--

LOCK TABLES `student_app_notice` WRITE;
/*!40000 ALTER TABLE `student_app_notice` DISABLE KEYS */;
INSERT INTO `student_app_notice` VALUES (1,'Exam Notice','Unit Test 1 Exams will be conducted from 24 Sept to 29 Sept. Attendance for everyone is compulsory. Those who won\'t attend exam will need to write assignments given by teachers',1),(2,'Test title','Test content',7);
/*!40000 ALTER TABLE `student_app_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_app_notice_class_obj`
--

DROP TABLE IF EXISTS `student_app_notice_class_obj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_app_notice_class_obj` (
  `id` tinyint(4) DEFAULT NULL,
  `notice_id` tinyint(4) DEFAULT NULL,
  `class_id` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_app_notice_class_obj`
--

LOCK TABLES `student_app_notice_class_obj` WRITE;
/*!40000 ALTER TABLE `student_app_notice_class_obj` DISABLE KEYS */;
INSERT INTO `student_app_notice_class_obj` VALUES (1,1,17),(2,1,18),(3,1,19),(4,1,20),(5,2,18);
/*!40000 ALTER TABLE `student_app_notice_class_obj` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_app_staff`
--

DROP TABLE IF EXISTS `student_app_staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_app_staff` (
  `id` tinyint(4) DEFAULT NULL,
  `first_name` varchar(7) DEFAULT NULL,
  `last_name` varchar(8) DEFAULT NULL,
  `email` varchar(24) DEFAULT NULL,
  `password` varchar(78) DEFAULT NULL,
  `staff_id` varchar(7) DEFAULT NULL,
  `gender` varchar(4) DEFAULT NULL,
  `designation` varchar(19) DEFAULT NULL,
  `register_time` varchar(10) DEFAULT NULL,
  `department_id` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_app_staff`
--

LOCK TABLES `student_app_staff` WRITE;
/*!40000 ALTER TABLE `student_app_staff` DISABLE KEYS */;
INSERT INTO `student_app_staff` VALUES (1,'Ranjeet','Bidwe','ranjeetbidwe@gmail.com','pbkdf2_sha256$150000$4LgdoYOZBClw$TUuQpEny6xOqgBYnZAXSSLkiKrnwi4yU/z4AaBPcTAw=','STF1000','male','professor','',1),(2,'Swarup','Suradkar','swarupsuradkar@gmail.com','pbkdf2_sha256$150000$wvJQgI2Rm5rB$tOC6OfJcx3QhM1aIzOiRi81Mi0EmwwHKqJCmjawCCEs=','STF1001','male','professor','',1),(3,'Bhushan','Zope','bhushanzope@gmail.com','pbkdf2_sha256$150000$9ZmKTYFf4O8E$dGvTX6v0rCkzT5CvFw8+0AfmWS7Q8WUKTP0gIuSnE/g=','STF1002','male','associate_professor','',1),(4,'Pravin','Patil','pravinpatil@gmail.com','pbkdf2_sha256$150000$D0BSmIjRC3du$MDpEHI0apxqm7htOxrIKGxhHKCrgfjcHR710FXbyUV8=','STF1003','male','assistant_professor','',1),(5,'Girish','Potdar','girishpotdar@gmail.com','pbkdf2_sha256$150000$5TKI5kbiHFL1$yTzc5wstWrMvayJIlbNMyBDY/2aS3XKfYtMJuFzLPUQ=','STF1004','male','assistant_professor','',1),(6,'Varad','Joshi','varadjoshi@gmail.com','pbkdf2_sha256$150000$mUvYmbwCa0A4$uFU1GvC+v45wszzcZ7BYiTINXP0hxNGQ5M+Pjtpadfc=','STF1005','male','librarian','2019-09-14',1),(7,'Prasad','Hole','prasadhole@gmail.com','pbkdf2_sha256$150000$HVPkcg4GioCX$ou5Fcol/eMyKnkuc9zpNKK9BRGmbMpjpplWYcmSgXjo=','STF1007','male','professor','',1),(8,'Akash ','Dongare','akashdongare@gmail.com','pbkdf2_sha256$150000$cTK5D35Dzt2D$0YXt9DZwQ1V5OTmuS7DUNee5IyHuGRxHPbKNGeL5SQ0=','12345','male','professor','2019-09-15',1);
/*!40000 ALTER TABLE `student_app_staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_app_staff_classes`
--

DROP TABLE IF EXISTS `student_app_staff_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_app_staff_classes` (
  `id` tinyint(4) DEFAULT NULL,
  `staff_id` tinyint(4) DEFAULT NULL,
  `class_id` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_app_staff_classes`
--

LOCK TABLES `student_app_staff_classes` WRITE;
/*!40000 ALTER TABLE `student_app_staff_classes` DISABLE KEYS */;
INSERT INTO `student_app_staff_classes` VALUES (9,1,17),(10,1,18),(11,1,19),(12,1,20),(7,2,18),(8,2,20),(4,3,17),(5,3,19),(6,3,20),(2,4,18),(3,4,20),(1,5,17),(13,7,18),(14,7,19),(15,7,20);
/*!40000 ALTER TABLE `student_app_staff_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_app_student`
--

DROP TABLE IF EXISTS `student_app_student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_app_student` (
  `id` tinyint(4) DEFAULT NULL,
  `first_name` varchar(11) DEFAULT NULL,
  `last_name` varchar(11) DEFAULT NULL,
  `email` varchar(27) DEFAULT NULL,
  `password` varchar(78) DEFAULT NULL,
  `student_id` varchar(7) DEFAULT NULL,
  `gender` varchar(4) DEFAULT NULL,
  `register_time` varchar(10) DEFAULT NULL,
  `_class_id` tinyint(4) DEFAULT NULL,
  `department_id` tinyint(4) DEFAULT NULL,
  `mobile_no` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_app_student`
--

LOCK TABLES `student_app_student` WRITE;
/*!40000 ALTER TABLE `student_app_student` DISABLE KEYS */;
INSERT INTO `student_app_student` VALUES (1,'Shobhit','Bhosure','shobhitbhosure7@gmail.com','pbkdf2_sha256$150000$6JXOJyNWzlbF$ssOGReNENAddTgkdnpb7PHH9r65Vz2vNM9UbUW6Rsv8=','C2K1000','male','2019-09-14',20,1,1286608618),(2,'Saurabh','Shinde','saurabhshinde@gmail.com','pbkdf2_sha256$150000$frQbFnH3suGc$Lh3nNbNIgEHPoJSGK6h+3p7EVYCSGjEta7cr4IZVu2o=','C2K1001','male','2019-09-14',20,1,1286608618),(3,'Arnav','Rahalkar','arnavrahalkar@gmail.com','pbkdf2_sha256$150000$nT8DBXoc66H5$hjzgd4P0tlIIIoq1GtV+xugq+Li7VJkpusEsJLu5LvA=','C2K1002','male','2019-09-14',20,1,1286608618),(4,'Aditya','Malte','adityamalte@gmail.com','pbkdf2_sha256$150000$6KxHw3hMRYe0$CGJOAY5JroRKf4Gqx2YECLWXluT/Oz3+rZ0EPP/l1dM=','C2K1003','male','2019-09-14',20,1,1286608618),(5,'Rohan','Suryawanshi','rohansuryawanshi@gmail.com','pbkdf2_sha256$150000$s0uqTF8oY7Hv$as7hJ1y3FWTpeNBWFvCytrL5otO7isqwU4TnHFZagK4=','C2K1004','male','2019-09-14',19,1,1286608618),(6,'Purushottam','Suryawanshi','psuryawanshi@gmail.com','pbkdf2_sha256$150000$fIoe0dCZpF2J$fsuNhcC681Dm7Bpjru4iKQZK4NbTJXGHb8xWafJY0cM=','C2K1005','male','2019-09-14',19,1,1286608618),(7,'Vitthal','Chandankar','vitthalchandankar@gmail.com','pbkdf2_sha256$150000$YX3ImqKwEGFV$9BdfEhT9y9YrGVT8FXotQH3qTvwtBcYoxwWkYGzQ4rE=','C2K1006','male','2019-09-14',19,1,1286608618),(8,'Kalyan','Jonwal','kalyanjonwal@gmail.com','pbkdf2_sha256$150000$Kcfw61ClvmW5$jSDPU9uJ02P3R1m2IOuNjOAKPAMK5KSj3tU70waTF3E=','C2K1007','male','2019-09-14',19,1,1286608618),(9,'Girish','Haral','girishharal@gmail.com','pbkdf2_sha256$150000$7TQ2V9ZMSQKR$f9VSydtbbeQAo3z4pbztDMqqmrDMzKJa7Y3NpX57Elk=','C2K1008','male','2019-09-14',18,1,1286608618),(10,'Neeraj','Panse','neerajpanse@gmail.com','pbkdf2_sha256$150000$xqvkNFeJatRO$HhaFeF7rZO4729KlEb0FMU79LrfcWAX4qInHqM3BsMY=','C2K1009','male','2019-09-14',18,1,1286608618),(11,'Neel','Bafna','neelbafna@gmail.com','pbkdf2_sha256$150000$i8b7RGc1EefS$C20mvFVDfbBWUbP0hAnwYtSBa8S/0iF6qzAtiUp3XxE=','C2K1010','male','2019-09-14',17,1,1286608618),(12,'Kaustubh','Phatak','kaustubhphatak@gmail.com','pbkdf2_sha256$150000$eGJwu309br0h$nIMi5dQyP2Yf9pLMQulSj+MihzTDUha3gfGkSd5JrWY=','C2K1011','male','2019-09-14',17,1,1286608618),(13,'Rakshit','Karande','rakshitkarande@gmail.com','pbkdf2_sha256$150000$Lj1lefLnlbNh$cPOjqzpZjk4gNojaHidLrygrnx4hLI5JZmFJGUKCCmw=','C2K1012','male','2019-09-15',18,1,1286608618),(14,'Vishal','Vish','vishalvish@gmail.com','pbkdf2_sha256$150000$o5c0Yqc8QrGg$AEvC3Ewuw2fuZJUIf524KJ8llQlOmr4TyQB7gmkJFNY=','C2K1014','male','2019-09-15',20,1,1286606649);
/*!40000 ALTER TABLE `student_app_student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_app_subject`
--

DROP TABLE IF EXISTS `student_app_subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_app_subject` (
  `id` tinyint(4) DEFAULT NULL,
  `name` varchar(27) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_app_subject`
--

LOCK TABLES `student_app_subject` WRITE;
/*!40000 ALTER TABLE `student_app_subject` DISABLE KEYS */;
INSERT INTO `student_app_subject` VALUES (1,'Physics'),(2,'Maths 1'),(3,'Maths 2'),(4,'Maths 3'),(5,'Chemistry'),(6,'Computer Fundamentals'),(13,'Object Oriented Programming'),(14,'Data Structures'),(15,'Microprocessor'),(16,'Advanced Microprocessor'),(17,'Software Testing'),(18,'Soft Skills'),(19,'Web Technology'),(20,'Data Mining & Warehousing'),(21,'Artificial Intelligence'),(22,'Cyber Security'),(23,'Software Development'),(24,'Theory of Computation'),(25,'DBMS'),(26,'Computer Networks'),(27,'Software Modelling'),(28,'ES & IOT'),(29,'System Programming and OS'),(30,'Data Analytics'),(31,'High Performance Computing');
/*!40000 ALTER TABLE `student_app_subject` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-22 15:26:21
